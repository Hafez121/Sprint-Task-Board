export const columns = ['todo', 'inprogress', 'done']

export const columnLabels = {
  todo: 'To Do',
  inprogress: 'In Progress',
  done: 'Done',
}

export const seedTasks = [
  { id: 't1', title: 'Set up project repo', priority: 'low', column: 'done' },
  { id: 't2', title: 'Wireframe the dashboard', priority: 'medium', column: 'done' },
  { id: 't3', title: 'Build auth flow', priority: 'high', column: 'inprogress' },
  { id: 't4', title: 'Style the settings page', priority: 'medium', column: 'inprogress' },
  { id: 't5', title: 'Write API docs', priority: 'low', column: 'todo' },
  { id: 't6', title: 'Fix mobile nav overflow', priority: 'high', column: 'todo' },
  { id: 't7', title: 'Add empty states', priority: 'medium', column: 'todo' },
]
