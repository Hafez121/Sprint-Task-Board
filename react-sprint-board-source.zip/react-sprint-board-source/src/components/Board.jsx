import { useLocalStorage } from '../hooks/useLocalStorage'
import { columns, columnLabels, seedTasks } from '../data/seedTasks'
import Column from './Column'

export default function Board() {
  const [tasks, setTasks] = useLocalStorage('sprint-board-tasks', seedTasks)

  function handleDragStart(e, taskId) {
    e.dataTransfer.setData('text/plain', taskId)
  }

  function handleDrop(taskId, targetColumn) {
    setTasks((prev) =>
      prev.map((t) => (t.id === taskId ? { ...t, column: targetColumn } : t))
    )
  }

  function handleDelete(taskId) {
    setTasks((prev) => prev.filter((t) => t.id !== taskId))
  }

  function handleAdd(column, title, priority) {
    const newTask = {
      id: `t${Date.now()}`,
      title,
      priority,
      column,
    }
    setTasks((prev) => [...prev, newTask])
  }

  function handleReset() {
    if (confirm('Reset board to the starting demo tasks?')) {
      setTasks(seedTasks)
    }
  }

  return (
    <div className="board-wrap">
      <div className="board-toolbar">
        <button className="reset-btn" onClick={handleReset}>Reset demo</button>
      </div>
      <div className="board">
        {columns.map((col) => (
          <Column
            key={col}
            id={col}
            label={columnLabels[col]}
            tasks={tasks.filter((t) => t.column === col)}
            onDrop={handleDrop}
            onDragStart={handleDragStart}
            onDelete={handleDelete}
            onAdd={handleAdd}
          />
        ))}
      </div>
    </div>
  )
}
