export default function TaskCard({ task, onDragStart, onDelete }) {
  return (
    <div
      className="task-card"
      draggable
      onDragStart={(e) => onDragStart(e, task.id)}
    >
      <div className="task-card-top">
        <span className={`priority-dot priority-${task.priority}`} />
        <button
          className="task-delete"
          onClick={() => onDelete(task.id)}
          aria-label="Delete task"
        >
          ×
        </button>
      </div>
      <p className="task-title">{task.title}</p>
    </div>
  )
}
