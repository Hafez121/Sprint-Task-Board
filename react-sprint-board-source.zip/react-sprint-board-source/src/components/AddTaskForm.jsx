import { useState } from 'react'

export default function AddTaskForm({ onAdd, onCancel }) {
  const [title, setTitle] = useState('')
  const [priority, setPriority] = useState('medium')

  function handleSubmit(e) {
    e.preventDefault()
    if (!title.trim()) return
    onAdd(title.trim(), priority)
    setTitle('')
    setPriority('medium')
  }

  return (
    <form className="add-task-form" onSubmit={handleSubmit}>
      <input
        type="text"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Task title…"
        autoFocus
      />
      <div className="add-task-row">
        <select value={priority} onChange={(e) => setPriority(e.target.value)}>
          <option value="low">Low</option>
          <option value="medium">Medium</option>
          <option value="high">High</option>
        </select>
        <button type="submit" className="add-task-confirm">Add</button>
        <button type="button" className="add-task-cancel" onClick={onCancel}>Cancel</button>
      </div>
    </form>
  )
}
