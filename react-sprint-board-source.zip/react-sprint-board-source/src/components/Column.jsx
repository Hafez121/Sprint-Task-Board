import { useState } from 'react'
import TaskCard from './TaskCard'
import AddTaskForm from './AddTaskForm'

export default function Column({ id, label, tasks, onDrop, onDragStart, onDelete, onAdd }) {
  const [isOver, setIsOver] = useState(false)
  const [showForm, setShowForm] = useState(false)

  function handleDragOver(e) {
    e.preventDefault()
    setIsOver(true)
  }

  function handleDrop(e) {
    e.preventDefault()
    setIsOver(false)
    const taskId = e.dataTransfer.getData('text/plain')
    onDrop(taskId, id)
  }

  return (
    <div
      className={`column ${isOver ? 'column-over' : ''}`}
      onDragOver={handleDragOver}
      onDragLeave={() => setIsOver(false)}
      onDrop={handleDrop}
    >
      <div className="column-header">
        <span className="column-title">{label}</span>
        <span className="column-count">{tasks.length}</span>
      </div>

      <div className="column-body">
        {tasks.map((task) => (
          <TaskCard key={task.id} task={task} onDragStart={onDragStart} onDelete={onDelete} />
        ))}
      </div>

      {showForm ? (
        <AddTaskForm
          onAdd={(title, priority) => {
            onAdd(id, title, priority)
            setShowForm(false)
          }}
          onCancel={() => setShowForm(false)}
        />
      ) : (
        <button className="column-add-btn" onClick={() => setShowForm(true)}>+ Add task</button>
      )}
    </div>
  )
}
